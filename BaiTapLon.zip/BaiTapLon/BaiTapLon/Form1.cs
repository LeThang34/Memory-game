﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiTapLon
{
    public partial class Form1 : Form
    {
        //Tạo biến ngẫu nhiễn
        Random random = new Random();
        Random random2 = new Random();
        Random random3 = new Random();

        //Tạo list chữa các biểu tượng sẽ có trong trò chơi
        List<string> icons1 = new List<string>()
        {
            //Mức độ dễ
             "a", "a", "n", "n", ".", ".", "p", "p", "t",
            "t", "y", "y"
        };
        List<string> icons = new List<string>()
        {
            //Mức độ trung bình
             "!", "!", "N", "N", ",", ",", "k", "k", "b",
            "b", "v", "v", "w", "w", "z", "z",
        };
        List<string> icons3 = new List<string>() {
       
        //Mức độ khó
        "a", "a", "L", "L", "y", "y", "q", "q", "i", "i", "r", "r", "s", "s", "!", "!", "N", "N", ",", ","
       };


        //Tạo hai biến để so sánh 2 biểu tương
        Label firstClicked1, secondClicked1, firstClicked, secondClicked, firstClicked3, secondClicked3;
        public Form1()
        {
            InitializeComponent();
            AssignIconsToSquares();
            AssignIconsToSquares2();
            AssignIconsToSquares3();
        }

        private void label_Click(object sender, EventArgs e)
        {
            if (firstClicked != null && secondClicked != null)
                return;

            Label clickerLabel = sender as Label;

            if (clickerLabel == null)
                return;
            if (clickerLabel.ForeColor == Color.Black)
                return;
            if (firstClicked == null)
            {
                firstClicked = clickerLabel;
                firstClicked.ForeColor = Color.Black;
                return;
            }
            secondClicked = clickerLabel;
            secondClicked.ForeColor = Color.Black;

            CheckForWiner();

            if (firstClicked.Text == secondClicked.Text)
            {
                firstClicked = null;
                secondClicked = null;
            }
            else
                timer1.Start();
        }
        private void CheckForWiner()
        {
            for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                Label label;
                label = tableLayoutPanel1.Controls[i] as Label;
                if (label != null && label.ForeColor == label.BackColor)
                    return;
            }

            MessageBox.Show("Chúc mừng bạn đã chiến thắng!", "Thông báo");
           // Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();

            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;

            firstClicked = null;
            secondClicked = null;
        }

        //Hàm gán biển tượng cho các ô vuông
        private void AssignIconsToSquares()
        {
            //Tạo biến ngẫu nhiên để lưu trữ tạm thời
            Label label;
            //Biến chứa số ngẫu nhiên để gán biểu tượng vào ô có số thứ tự đó
            int randomNumber;

            for(int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                if (tableLayoutPanel1.Controls[i] is Label)
                {
                    label = (Label)tableLayoutPanel1.Controls[i];
                }
         
                else
                    continue;
                //Nhận 1 số ngẫu nhiên
                randomNumber = random.Next(0, icons.Count);
                //icon có thứ tự là số ngẫu nhiên đó sẽ được gán cho label
                label.Text = icons[randomNumber];
                //Xóa số ngẫu nhiên khỏi danh sách icon
                icons.RemoveAt(randomNumber);   
            }
        }


        //Mức độ dễ
        private void label1_Click(object sender, EventArgs e)
        {
            if (firstClicked1 != null && secondClicked1 != null)
                return;

            Label clickerLabel = sender as Label;

            if (clickerLabel == null)
                return;
            if (clickerLabel.ForeColor == Color.Black)
                return;
            if (firstClicked1 == null)
            {
                firstClicked1 = clickerLabel;
                firstClicked1.ForeColor = Color.Black;
                return;
            }
            secondClicked1 = clickerLabel;
            secondClicked1.ForeColor = Color.Black;

            CheckForWiner1();

            if (firstClicked1.Text == secondClicked1.Text)
            {
                firstClicked1 = null;
                secondClicked1 = null;
            }
            else
                timer2.Start();
        }
        private void CheckForWiner1()
        {
            for (int i = 0; i < tableLayoutPanel2.Controls.Count; i++)
            {
                Label label;
                label = tableLayoutPanel2.Controls[i] as Label;
                if (label != null && label.ForeColor == label.BackColor)
                    return;
            }

            MessageBox.Show("Chúc mừng bạn đã chiến thắng!", "Thông báo");
            // Close();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();

            firstClicked1.ForeColor = firstClicked1.BackColor;
            secondClicked1.ForeColor = secondClicked1.BackColor;

            firstClicked1 = null;
            secondClicked1 = null;
        }



        private void AssignIconsToSquares2() {
            //Tạo biến ngẫu nhiên để lưu trữ tạm thời
            Label label2;
            //Biến chứa số ngẫu nhiên để gán biểu tượng vào ô có số thứ tự đó
            int randomNumber2;
            for (int i = 0; i < tableLayoutPanel2.Controls.Count; i++)
            {
                if (tableLayoutPanel2.Controls[i] is Label)
                {
                    label2 = (Label)tableLayoutPanel2.Controls[i];
                }

                else
                    continue;
                //Nhận 1 số ngẫu nhiên
                randomNumber2 = random2.Next(0, icons1.Count);
                //icon có thứ tự là số ngẫu nhiên đó sẽ được gán cho label
                label2.Text = icons1[randomNumber2];
                //Xóa số ngẫu nhiên khỏi danh sách icon
                icons1.RemoveAt(randomNumber2);
            }
        }

        //Mức độ khó

        private void label3_Click(object sender, EventArgs e)
        {
            if (firstClicked3 != null && secondClicked3 != null)
                return;

            Label clickerLabel = sender as Label;

            if (clickerLabel == null)
                return;
            if (clickerLabel.ForeColor == Color.Black)
                return;
            if (firstClicked3 == null)
            {
                firstClicked3 = clickerLabel;
                firstClicked3.ForeColor = Color.Black;
                return;
            }
            secondClicked3 = clickerLabel;
            secondClicked3.ForeColor = Color.Black;

            CheckForWiner3();

            if (firstClicked3.Text == secondClicked3.Text)
            {
                firstClicked3 = null;
                secondClicked3 = null;
            }
            else
                timer3.Start();
        }
        private void CheckForWiner3()
        {
            for (int i = 0; i < tableLayoutPanel3.Controls.Count; i++)
            {
                Label label;
                label = tableLayoutPanel3.Controls[i] as Label;
                if (label != null && label.ForeColor == label.BackColor)
                    return;
            }

            MessageBox.Show("Chúc mừng bạn đã chiến thắng!", "Thông báo");
            // Close();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();

            firstClicked3.ForeColor = firstClicked3.BackColor;
            secondClicked3.ForeColor = secondClicked3.BackColor;

            firstClicked3 = null;
            secondClicked3 = null;
        }



        private void AssignIconsToSquares3()
        {
            //Tạo biến ngẫu nhiên để lưu trữ tạm thời
            Label label2;
            //Biến chứa số ngẫu nhiên để gán biểu tượng vào ô có số thứ tự đó
            int randomNumber3;
            for (int i = 0; i < tableLayoutPanel3.Controls.Count; i++)
            {
                if (tableLayoutPanel3.Controls[i] is Label)
                {
                    label2 = (Label)tableLayoutPanel3.Controls[i];
                }

                else
                    continue;
                //Nhận 1 số ngẫu nhiên
                randomNumber3 = random3.Next(0, icons3.Count);
                //icon có thứ tự là số ngẫu nhiên đó sẽ được gán cho label
                label2.Text = icons3[randomNumber3];
                //Xóa số ngẫu nhiên khỏi danh sách icon
                icons3.RemoveAt(randomNumber3);
            }
        }

    }
}
